# Hanzi Stroke Polish v7

Patch nhỏ sau v6:

- Bỏ chữ "Bước 1" và "Bước 2" khỏi giao diện học.
- Làm 2 nút nhanh "Tự phát" và "Thứ tự nét" gọn hơn.
- Giữ nguyên logic tra nghĩa cụm từ từ JSON của v6.
- Không đổi dữ liệu JSON.

## File cần chép

Chép đè vào `modules/hanzi-stroke/`:

- `index.html`
- `style.css`
- `app.js`

## Test

Test các input:

- 星期
- 星期天
- 星期日
- 中文
- 汉字
- 学习

## Commit

```powershell
git add modules/hanzi-stroke/index.html modules/hanzi-stroke/style.css modules/hanzi-stroke/app.js
git commit -m "Simplify Hanzi stroke learning controls"
git push
```
